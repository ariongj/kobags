"use client";
import { useState } from "react";
import { useKobags } from "./kobags-context";
import { initialDesign } from "@/lib/catalog";
export default function CookieControls() {
  const { update } = useKobags();
  const [done, setDone] = useState(false);
  return (
    <div>
      <button
        className="button secondary"
        onClick={() => {
          update({ ...initialDesign, key: crypto.randomUUID() });
          localStorage.removeItem("kobags-quote-step");
          setDone(true);
        }}
      >
        Clear this browser’s design draft
      </button>
      {done && (
        <p role="status">
          The local design draft has been cleared. Submitted demo records remain
          in your demo workspace.
        </p>
      )}
    </div>
  );
}
