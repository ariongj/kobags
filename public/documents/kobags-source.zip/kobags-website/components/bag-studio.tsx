"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import Link from "@/components/site-link";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Download,
  Upload,
  Move,
  RotateCcw,
  Minus,
  Plus,
  Maximize2,
  Package,
  ShieldCheck,
  Leaf,
  Info,
  Type,
  ImagePlus,
} from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { products, colors, Design, getProduct } from "@/lib/catalog";
import { useKobags } from "./kobags-context";
export function Choice({
  id,
  value,
  onChange,
  options,
  label,
}: {
  id: string;
  value: string;
  onChange: (s: string) => void;
  options: { value: string; label: string }[];
  label: string;
}) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger id={id} className="choice">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {options.map((o) => (
            <SelectItem value={o.value} key={o.value}>
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
export function BagPreview({
  design,
  onChange,
  canvasRef,
  compact = false,
}: {
  design: Design;
  onChange?: (p: Partial<Design>) => void;
  canvasRef?: React.RefObject<HTMLCanvasElement | null>;
  compact?: boolean;
}) {
  const ownRef = useRef<HTMLCanvasElement>(null);
  const ref = canvasRef || ownRef;
  const imageRef = useRef<HTMLImageElement | null>(null);
  const [loaded, setLoaded] = useState(0);
  const p = getProduct(design.product);
  const back = design.side === "back";
  const logo = back ? design.backLogo : design.logo;
  const text = back ? design.backText : design.text;
  const x = back ? design.backX : design.x;
  const y = back ? design.backY : design.y;
  const scale = back ? design.backScale : design.scale;
  const rotation = back ? design.backRotation : design.rotation;
  const drag = useRef(false);
  useEffect(() => {
    const im = new Image();
    im.onload = () => {
      imageRef.current = im;
      setLoaded((n) => n + 1);
    };
    im.src = "/assets/studio-bag-atlas.png";
  }, [p.image]);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    let cancelled = false;
    const draw = async () => {
      ctx.clearRect(0, 0, 800, 800);
      const im = imageRef.current;
      if (!im) return;
      const layer = document.createElement("canvas");
      layer.width = 800;
      layer.height = 800;
      const l = layer.getContext("2d")!;
      const index = products.findIndex((item) => item.slug === p.slug);
      const bounds = [
        [0, 386],
        [396, 780],
        [780, 1190],
        [1200, 1565],
        [1568, 1983],
      ][index];
      const sx = bounds[0];
      const crop = bounds[1] - sx;
      const fit = Math.min(680 / crop, 690 / 640);
      const w = crop * fit,
        h = 640 * fit;
      l.drawImage(im, sx, 60, crop, 640, (800 - w) / 2, (800 - h) / 2, w, h);
      try {
        const data = l.getImageData(0, 0, 800, 800);
        const hex = (colors.find((c) => c.name === design.color) || colors[0])
          .hex;
        const rgb = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
        for (let i = 0; i < data.data.length; i += 4) {
          if (data.data[i + 3] === 0) continue;
          const lum = (data.data[i] + data.data[i + 1] + data.data[i + 2]) / 3;
          if (lum > 237) {
            data.data[i + 3] = 0;
            continue;
          }
          const shade = Math.min(1.18, 0.4 + lum / 260);
          data.data[i] = rgb[0] * shade;
          data.data[i + 1] = rgb[1] * shade;
          data.data[i + 2] = rgb[2] * shade;
        }
        l.putImageData(data, 0, 0);
      } catch {}
      ctx.drawImage(layer, 0, 0);
      ctx.save();
      ctx.translate(x * 8, y * 8);
      ctx.rotate((rotation * Math.PI) / 180);
      if (logo) {
        const mark = new Image();
        await new Promise<void>((resolve) => {
          mark.onload = () => resolve();
          mark.onerror = () => resolve();
          mark.src = logo;
        });
        if (cancelled) return;
        const w = scale * 8,
          h = (mark.naturalHeight / mark.naturalWidth) * w;
        if (mark.naturalWidth) ctx.drawImage(mark, -w / 2, -h / 2, w, h);
      } else if (text) {
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = design.ink;
        ctx.font = `700 ${scale * 1.9}px Arial`;
        const lines = text.split("\n");
        lines.forEach((line, i) =>
          ctx.fillText(
            line,
            0,
            (i - (lines.length - 1) / 2) * scale * 2.1,
            440,
          ),
        );
      }
      ctx.restore();
    };
    draw();
    return () => {
      cancelled = true;
    };
  }, [design, loaded, ref, x, y, scale, rotation, logo, text]);
  const move = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drag.current || !onChange) return;
    const r = e.currentTarget.getBoundingClientRect();
    const dx = Math.max(
      24,
      Math.min(76, ((e.clientX - r.left) / r.width) * 100),
    );
    const dy = Math.max(
      33,
      Math.min(80, ((e.clientY - r.top) / r.height) * 100),
    );
    onChange(back ? { backX: dx, backY: dy } : { x: dx, y: dy });
  };
  return (
    <canvas
      ref={ref}
      width="800"
      height="800"
      className={"bag-canvas " + (compact ? "compact" : "")}
      role="img"
      aria-label={`${p.name}, ${design.color}, ${back ? "back" : "front"} branding preview. Indicative only.`}
      tabIndex={onChange ? 0 : undefined}
      onPointerDown={(e) => {
        if (onChange) {
          drag.current = true;
          e.currentTarget.setPointerCapture(e.pointerId);
          move(e);
        }
      }}
      onPointerMove={move}
      onPointerUp={() => (drag.current = false)}
      onPointerCancel={() => (drag.current = false)}
      onKeyDown={(e) => {
        if (!onChange) return;
        const dx = e.key === "ArrowLeft" ? -1 : e.key === "ArrowRight" ? 1 : 0,
          dy = e.key === "ArrowUp" ? -1 : e.key === "ArrowDown" ? 1 : 0;
        if (dx || dy) {
          e.preventDefault();
          onChange(
            back
              ? {
                  backX: Math.max(24, Math.min(76, x + dx)),
                  backY: Math.max(33, Math.min(80, y + dy)),
                }
              : {
                  x: Math.max(24, Math.min(76, x + dx)),
                  y: Math.max(33, Math.min(80, y + dy)),
                },
          );
        }
      }}
    />
  );
}
export default function BagStudio() {
  const { design, update, t } = useKobags();
  const p = getProduct(design.product);
  const v = p.variants.find((v) => v.name === design.size) || p.variants[0];
  const [tab, setTab] = useState("bag");
  const [error, setError] = useState("");
  const [full, setFull] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const canvas = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const back = design.side === "back";
  const upload = async (file?: File) => {
    if (!file) return;
    setError("");
    if (
      !["image/png", "image/jpeg", "image/webp"].includes(file.type) ||
      file.size > 5 * 1024 * 1024
    ) {
      setError(
        t(
          "Choose a PNG, JPG or WebP image under 5 MB.",
          "Zgjidhni PNG, JPG ose WebP nën 5 MB.",
        ),
      );
      return;
    }
    try {
      const bitmap = await createImageBitmap(file);
      if (bitmap.width > 8000 || bitmap.height > 8000) throw Error();
      const c = document.createElement("canvas");
      const fit = Math.min(1, 320 / Math.max(bitmap.width, bitmap.height));
      c.width = bitmap.width * fit;
      c.height = bitmap.height * fit;
      c.getContext("2d")!.drawImage(bitmap, 0, 0, c.width, c.height);
      const image = c.toDataURL("image/webp", 0.85);
      if (image.length > 100000) throw Error();
      update(
        back
          ? { backLogo: image, backText: "", logoName: file.name }
          : { logo: image, text: "", logoName: file.name },
      );
      bitmap.close();
      setTab("artwork");
    } catch {
      setError(
        t(
          "This image could not be read. Try a smaller PNG or JPG.",
          "Imazhi nuk u lexua. Provoni një PNG ose JPG më të vogël.",
        ),
      );
    }
  };
  const download = () => {
    if (!canvas.current) return;
    const a = document.createElement("a");
    const output = document.createElement("canvas");
    output.width = 800;
    output.height = 880;
    const ctx = output.getContext("2d")!;
    ctx.fillStyle = "#f6f7f3";
    ctx.fillRect(0, 0, 800, 880);
    ctx.drawImage(canvas.current, 0, 0);
    ctx.fillStyle = "#193b67";
    ctx.font = "16px Arial";
    ctx.textAlign = "center";
    ctx.fillText("KOBAGS BAG STUDIO · ILLUSTRATIVE CONCEPT", 400, 826);
    ctx.font = "13px Arial";
    ctx.fillText(
      "Final shape, color and print placement require production approval.",
      400,
      851,
    );
    a.href = output.toDataURL("image/png");
    a.download = `kobags-${p.slug}-${design.side}-concept.png`;
    a.click();
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2500);
  };
  return (
    <section className="studio-section">
      <div className="studio-heading">
        <div>
          <p className="eyebrow">
            <span className="tiny-rule" />
            {t("THE KOBAGS BAG STUDIO", "STUDIOJA E ÇANTAVE KOBAGS")}
          </p>
          <h1>
            {t("Your brand.", "Marka juaj.")}{" "}
            <span>{t("Your bag.", "Çanta juaj.")}</span>
          </h1>
          <p>
            {t(
              "Pick a shape. Make it yours. See your next bag come to life.",
              "Zgjidhni formën. Personalizojeni. Shihni çantën tuaj të ardhshme.",
            )}
          </p>
        </div>
        <div className="studio-heading-note">
          <span className="pill">
            <span className="status-dot" />
            {t("LIVE DESIGN PREVIEW", "PARAPAMJE E DIZAJNIT")}
          </span>
          <span>
            {t("Made in Lipjan, Kosovo", "Prodhuar në Lipjan, Kosovë")}
          </span>
        </div>
      </div>
      <div className="studio">
        <div className="preview-column">
          <div className="bag-picker">
            {products.map((b) => (
              <button
                key={b.slug}
                className={b.slug === p.slug ? "bag-pick selected" : "bag-pick"}
                onClick={() =>
                  update({ product: b.slug, size: b.variants[0].name })
                }
                aria-pressed={b.slug === p.slug}
              >
                <img src={b.image} alt="" width="72" height="72" />
                <span>{b.name.replace(" Bag", "")}</span>
                {b.slug === p.slug && <Check size={12} />}
              </button>
            ))}
          </div>
          <div className="preview-stage">
            <div className="stage-top">
              <span>
                {p.name} <span className="subtle">/ {design.size}</span>
              </span>
              <button
                className="icon-button"
                onClick={() => setFull(true)}
                aria-label={t("Enlarge preview", "Zmadho pamjen")}
              >
                <Maximize2 size={18} />
              </button>
            </div>
            <BagPreview design={design} onChange={update} canvasRef={canvas} />
            <div className="stage-label">
              <span>NON-WOVEN PP</span>
              <span>
                {v.gsm} GSM · {v.dimensions}
              </span>
            </div>
            <div className="stage-bottom">
              <Tabs
                value={design.side}
                onValueChange={(s) => update({ side: s as "front" | "back" })}
              >
                <TabsList className="side-switch">
                  <TabsTrigger value="front">
                    {t("Front", "Përpara")}
                  </TabsTrigger>
                  <TabsTrigger value="back">{t("Back", "Prapa")}</TabsTrigger>
                </TabsList>
              </Tabs>
              <span className="drag-tip">
                <Move size={14} />
                {t(
                  "Drag your artwork to position",
                  "Lëvizni dizajnin për ta pozicionuar",
                )}
              </span>
              <button
                className="icon-button"
                onClick={download}
                aria-label={t("Download design preview", "Shkarko parapamjen")}
              >
                {downloaded ? <Check size={18} /> : <Download size={18} />}
              </button>
            </div>
          </div>
          <div className="preview-disclaimer">
            <Info size={14} />
            {t(
              "Illustrative bag rendering. Color, shape, scale and print placement need production approval.",
              "Paraqitje ilustruese. Ngjyra, forma, shkalla dhe shtypi kërkojnë miratim.",
            )}
          </div>
        </div>
        <aside className="studio-controls">
          <div className="controls-heading">
            <span className="eyebrow">
              {t("LET’S MAKE IT YOURS", "TA PERSONALIZOJMË")}
            </span>
            <h2>
              {t("A bag with your name on it.", "Një çantë me emrin tuaj.")}
            </h2>
          </div>
          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="editor-tabs">
              <TabsTrigger value="bag">
                01 <span>{t("The bag", "Çanta")}</span>
              </TabsTrigger>
              <TabsTrigger value="artwork">
                02 <span>{t("Your design", "Dizajni juaj")}</span>
              </TabsTrigger>
            </TabsList>
            <TabsContent value="bag" className="editor-body">
              <Choice
                id="bag-size"
                label={t("Bag size", "Madhësia e çantës")}
                value={design.size}
                onChange={(size) => update({ size })}
                options={p.variants.map((v) => ({
                  value: v.name,
                  label: `${v.name} · ${v.dimensions}`,
                }))}
              />
              <div className="field">
                <div className="field-title">
                  <label>{t("Bag color", "Ngjyra e çantës")}</label>
                  <span>
                    {t(
                      design.color,
                      colors.find((c) => c.name === design.color)?.sq,
                    )}
                  </span>
                </div>
                <div
                  className="swatches"
                  role="group"
                  aria-label={t("Bag color", "Ngjyra e çantës")}
                >
                  {colors.map((c) => (
                    <button
                      key={c.name}
                      className={
                        design.color === c.name ? "swatch selected" : "swatch"
                      }
                      style={{ background: c.hex }}
                      aria-label={c.name}
                      aria-pressed={design.color === c.name}
                      title={c.name}
                      onClick={() => update({ color: c.name })}
                    >
                      {design.color === c.name && (
                        <Check
                          size={16}
                          color={
                            ["Natural", "White"].includes(c.name)
                              ? "#193b67"
                              : "white"
                          }
                        />
                      )}
                    </button>
                  ))}
                </div>
                <small>
                  {t(
                    "Color options are indicative; availability is confirmed with your quote.",
                    "Ngjyrat janë orientuese; disponueshmëria konfirmohet me ofertën.",
                  )}
                </small>
              </div>
              <div className="spec-mini">
                <div>
                  <Package size={17} />
                  <span>
                    {t("Material", "Materiali")}
                    <strong>Non-woven PP</strong>
                  </span>
                </div>
                <div>
                  <ShieldCheck size={17} />
                  <span>
                    {t("Fabric weight", "Pesha e materialit")}
                    <strong>{v.gsm} g/m²</strong>
                  </span>
                </div>
              </div>
              <button
                className="upload-zone"
                onClick={() => {
                  setTab("artwork");
                  fileRef.current?.click();
                }}
              >
                <span className="upload-icon">
                  <Upload size={21} />
                </span>
                <strong>
                  {design.logoName || t("Add your logo", "Shtoni logon tuaj")}
                </strong>
                <span>
                  {t(
                    "PNG, JPG or WebP · up to 5 MB",
                    "PNG, JPG ose WebP · deri 5 MB",
                  )}
                </span>
              </button>
              <button
                className="text-button design-next"
                onClick={() => setTab("artwork")}
              >
                {t(
                  "Or start with your brand name",
                  "Ose filloni me emrin e markës",
                )}{" "}
                <ArrowRight size={15} />
              </button>
            </TabsContent>
            <TabsContent value="artwork" className="editor-body">
              <button
                className="upload-zone short"
                onClick={() => fileRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  upload(e.dataTransfer.files[0]);
                }}
              >
                <Upload size={20} />
                <strong>
                  {t("Upload or drop your logo", "Ngarkoni ose hidhni logon")}
                </strong>
                <span>PNG, JPG, WebP · 5 MB</span>
              </button>
              <div className="field">
                <label htmlFor="brand-text">
                  {t("Or type your brand name", "Ose shkruani emrin e markës")}
                </label>
                <textarea
                  id="brand-text"
                  rows={2}
                  maxLength={60}
                  value={back ? design.backText : design.text}
                  onChange={(e) =>
                    update(
                      back
                        ? { backText: e.target.value, backLogo: "" }
                        : { text: e.target.value, logo: "" },
                    )
                  }
                />
              </div>
              <div className="field-title">
                <label htmlFor="ink">
                  {t("Print color", "Ngjyra e shtypit")}
                </label>
                <input
                  type="color"
                  id="ink"
                  value={design.ink}
                  onChange={(e) => update({ ink: e.target.value })}
                />
              </div>
              <div className="range-field">
                <div className="field-title">
                  <label id="scale-label">
                    {t("Artwork size", "Madhësia e dizajnit")}
                  </label>
                  <span>{back ? design.backScale : design.scale}%</span>
                </div>
                <Slider
                  aria-labelledby="scale-label"
                  min={10}
                  max={55}
                  step={1}
                  value={[back ? design.backScale : design.scale]}
                  onValueChange={([s]) =>
                    update(back ? { backScale: s } : { scale: s })
                  }
                />
              </div>
              <div className="range-field">
                <div className="field-title">
                  <label id="rotate-label">{t("Rotation", "Rrotullimi")}</label>
                  <span>{back ? design.backRotation : design.rotation}°</span>
                </div>
                <Slider
                  aria-labelledby="rotate-label"
                  min={-45}
                  max={45}
                  step={1}
                  value={[back ? design.backRotation : design.rotation]}
                  onValueChange={([r]) =>
                    update(back ? { backRotation: r } : { rotation: r })
                  }
                />
              </div>
              <div className="artwork-actions">
                <button
                  className="text-button"
                  onClick={() =>
                    update(
                      back
                        ? { backX: 50, backY: 56, backRotation: 0 }
                        : { x: 50, y: 56, rotation: 0 },
                    )
                  }
                >
                  <RotateCcw size={14} />
                  {t("Center artwork", "Qendro dizajnin")}
                </button>
                <button
                  className="text-button"
                  onClick={() =>
                    update(
                      back
                        ? { backLogo: "", backText: "" }
                        : { logo: "", text: "", logoName: "" },
                    )
                  }
                >
                  {t("Remove", "Hiq")}
                </button>
              </div>
              <p className="micro">
                {t(
                  "Drag the design on the bag, or focus the preview and use the arrow keys.",
                  "Lëvizni dizajnin mbi çantë, ose përdorni tastet me shigjeta.",
                )}
              </p>
            </TabsContent>
          </Tabs>
          <input
            ref={fileRef}
            type="file"
            className="sr-only"
            accept="image/png,image/jpeg,image/webp"
            aria-label="Upload logo"
            onChange={(e) => upload(e.target.files?.[0])}
          />
          {error && (
            <p className="error" role="alert">
              {error}
            </p>
          )}
          <div className="studio-quote">
            <div>
              <span>{t("Wholesale orders", "Porosi me shumicë")}</span>
              <strong>{t("From 5,000 bags", "Nga 5.000 çanta")}</strong>
            </div>
            <Link href="/quote" className="button">
              {t("Get a quote for this bag", "Kërkoni ofertë për këtë çantë")}{" "}
              <ArrowUpRight size={18} />
            </Link>
            <p>
              {t(
                "No payment now. Your design goes with your request.",
                "Pa pagesë tani. Dizajni dërgohet me kërkesën.",
              )}
            </p>
          </div>
        </aside>
      </div>
      <div className="studio-benefits">
        <span>
          <Package size={18} />
          {t(
            "Five shapes. One distinctive brand.",
            "Pesë forma. Një markë e veçantë.",
          )}
        </span>
        <span>
          <ShieldCheck size={18} />
          {t(
            "Artwork approval before production",
            "Miratim i dizajnit para prodhimit",
          )}
        </span>
        <Link href="/samples">
          {t(
            "Want to feel the material? Request samples",
            "Dëshironi ta prekni materialin? Kërkoni mostra",
          )}{" "}
          <ArrowUpRight size={15} />
        </Link>
      </div>
      <Dialog open={full} onOpenChange={setFull}>
        <DialogContent className="preview-dialog">
          <DialogTitle>
            {p.name} · {design.color}
          </DialogTitle>
          <DialogDescription>
            {t(
              "Your design preview. Indicative only.",
              "Parapamja e dizajnit tuaj. Vetëm orientuese.",
            )}
          </DialogDescription>
          <BagPreview design={design} />
          <button className="button" onClick={download}>
            <Download size={16} /> {t("Download preview", "Shkarko parapamjen")}
          </button>
        </DialogContent>
      </Dialog>
    </section>
  );
}
