import { ProductCatalog } from "@/components/product-catalog";
export const metadata = { title: "Reusable bag collection" };
export default function Page() {
  return <ProductCatalog />;
}
