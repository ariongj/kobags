import DemoWorkspace from "@/components/demo-workspace";
export const metadata = { title: "Sales demonstration" };
export default function Page() {
  return <DemoWorkspace role="admin" />;
}
