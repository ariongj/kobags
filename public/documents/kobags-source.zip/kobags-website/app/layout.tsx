import type { Metadata } from "next";
import "./globals.css";
import { KobagsProvider } from "@/components/kobags-context";
import { Header, Footer } from "@/components/site-shell";
export const metadata: Metadata = {
  title: {
    default: "Kobags Group | Design your own bag",
    template: "%s | Kobags Group",
  },
  description:
    "Choose a reusable bag, place your logo and preview your design. Explore the Kobags Group wholesale bag studio, manufactured in Kosovo.",
  robots: { index: false, follow: false },
  icons: { icon: "/assets/favicon.png" },
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <KobagsProvider>
          <a href="#main-content" className="skip-link">
            Skip to content
          </a>
          <Header />
          <div id="main-content">{children}</div>
          <Footer />
        </KobagsProvider>
      </body>
    </html>
  );
}
